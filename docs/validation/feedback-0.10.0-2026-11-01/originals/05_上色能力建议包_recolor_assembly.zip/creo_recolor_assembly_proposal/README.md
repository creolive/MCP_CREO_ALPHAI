# CREO_MechDog 装配上色能力建议包（recolor-assembly）

- 日期：2026-10-31
- 建议新增能力：`creo_recolor_assembly`（按零件族给装配组件上色）+ 读回校验
- 提出背景：MCP_CREO_MechDog 0.10.0 的 94 个工具中无任何外观/颜色操作（native 层 grep `appearance`/`ProColormap`/`RGB` 零命中）；用户提出"给 80 组件装配里的所有零件按零件族上不同颜色"时无法实现。本包用 Pro/TOOLKIT 官方接口**验证了可行性**，全部源码可直接移植。
- 环境：Windows 11 x64 / Creo Parametric 10.0.0.0（release_numeric=42）/ VS2022 BuildTools MSVC 14.44 / 异步模式（ProEngineerConnect 连接已运行会话）
- 实测结果：**80/80 组件上色成功、0 错误、保存成功；独立读回校验 12 族计数与期望逐项一致。**

---

## 一、需求

用户原话："给装配体里的所有零件上不同色"。具体场景：一个 80 组件的 Strandbeest 机构装配（12 种零件族：曲柄盘×1、机架板×4、主轴×2、3Link 销×18、4Link 销×6、四种连杆各×6、两块三角板各×12、风扇×1），按**零件族**（不是按实例）上 12 种颜色，用于装配验收的目视分辨。

对照：SolidWorks 侧的 `Solidworks_AssetMate_MechDog` 已有 `recolor_assembly`（`{"Crank": [0.88,0.2,0.18]}` 按族上色、dry-run、读回），Creo 侧无对应物。

## 二、关键接口（Creo 10 Pro/TOOLKIT，本机头文件实测）

全部来自 `D:\Program Files\PTC\Creo 10.0.0.0\Common Files\protoolkit\includes\`：

| 接口 | 头文件:行 | 用途 |
|---|---|---|
| `ProEngineerConnect` | ProCore.h:108 | 异步连接已运行会话（MCP worker.cpp 已在用同一接口） |
| `ProSolidFeatVisit` + `ProFeatureVisitAction` / `ProFeatureFilterAction` | ProSolid.h:494/514/534 | 遍历装配组件特征（filter 判 `PRO_FEAT_COMPONENT`=1000，ProFeatType.h:103） |
| `ProAsmcompMdlGet` | ProAsmcomp.h:474 | 由组件特征取组件模型 |
| `ProAsmcomppathInit` | ProAsmcomppath.h:11 | 构造组件路径（`ProIdTable tab; tab[0]=feat_id; size=1`） |
| `ProAsmcompAsmitemInit` | ProAsmcomp.h:1401 | 构造 **ProAsmitem**（外观 API 的入参） |
| `ProMdlVisibleSideAppearancepropsSet/Get` | ProMdl.h:2587/2670 | **组件/子装配级上色与读回**（Set 后需 `ProWindowRepaint`，见头文件注释） |
| `ProSurfaceAppearanceProps` | ProSurface.h:133 | 颜色结构：`color_rgb`(ProVector)、`ambient/diffuse/highlite/shininess/transparency/reflection`、`highlight_color`、`name/label/description/keywords`(ProPath) |
| `ProSurfaceAppearanceDefaultPropsGet` | ProSurface.h:1174 | 取默认外观（枚举 PRO_DEF_APPEARANCE_SOLID 等） |
| `ProWindowRepaint` | ProWindows.h:99 | 上色后刷新显示 |
| `ProMdlSave` | ProMdl.h:255 | 保存（外观随装配文件持久化，实测 `.asm` 版本号 +1） |

面级（更细粒度）同族接口：`ProSurfaceSideAppearancepropsSet/Get`（ProSurface.h:1017/1043）。

## 三、两个必须注意的坑（实测踩过）

### 坑 1：`ProAsmcompAsmitemInit` 的 `item_type` 必须传组件模型的类型

- 传 `PRO_FEATURE`（3）：`ProAsmcompAsmitemInit` 本身返回 0（成功），但后续 `ProMdlVisibleSideAppearancepropsSet` 一律返回 `PRO_TK_INVALID_TYPE = -18`，80 个组件全部失败。
- 正确做法：`ProMdlTypeGet(mdl, &mtype)` 后传组件模型类型（本例全是 `PRO_MDL_PART`）。
- 这正是头文件注释里那句 *"name — used for PRO_PARAMETER in this case item_type should be PRO_PART or PRO_ASSEMBLY"* 的真实含义，但注释只讲了 `name` 参数的场合，`item_type` 的约束只在错误码上暴露，建议 MCP 实现时在文档里写明。

### 坑 2：组件 → 零件族的映射语义

- MCP 的 `assemble_component` 是按序插入的，`ProSolidFeatVisit` 返回顺序 == 特征树序 == 插入序。因此"第 n 个被访问的组件"对应"第 n 条 assemble_component 操作"。
- 本包的调用方持有自己的操作序（c01..c80），用一张 80 项静态表映射族号（`recolor_worker.cpp` 内 `g_comp_family[80]`），并与生成装配的源数据逐项核对一致。
- **对 MCP 的建议**：`creo_recolor_assembly` 应以 `{part_number: [r,g,b]}` 或 `{model_name: [r,g,b]}` 为键（每个组件先 `ProAsmcompMdlGet` + `ProMdlNameGet` 再匹配），而不是依赖插入序——插入序只在本包里可用，因为调用方自己生成的装配。

## 四、实测过程与数据

1. 编译：MCP `build.cmd` 同款 MSVC 环境（`PRO_MACHINE=36 /DPRO_OS=4 /DPRO_USE_VAR_ARGS`，链接 `protkmd_NU.lib + ptaskyncmd.lib + ucore.lib + udata.lib` + 系统库），编译 0 警告 0 错误。
2. 运行（`PRO_COMM_MSG_EXE` + `PATH` 指向 `Common Files\x86e_win64\{obj,lib}`，与 MCP `bridge.py: native_environment()` 一致）：

```
recolor_worker.exe STRANDBEEST_ASM 30
→ {"ok":true,"painted":80,"unpainted":0,"errors":0,"saved":true,
   "families":[1,4,2,18,6,6,6,6,6,12,12,1]}
```

3. 独立读回校验（第二个程序 `verify_color.exe` 重新连接、逐组件 `ProMdlVisibleSideAppearancepropsGet`，按 RGB 聚类 12 族）：

```
verify_color.exe STRANDBEEST_ASM 30
→ {"read":80,"families":[12,12,18,6,6,6,1,6,6,4,1,2]}
   12/12 族计数与期望一致（EBD 12、IGH 12、3Link 18、4Link 6、四杆各 6、机架 4、主轴 2、曲柄 1、风扇 1）
```

4. 保存确认：`ProMdlSave` 产出 `strandbeest_asm.asm.5 → .asm.8`（每次保存版本号 +1），颜色随装配持久化。

## 五、建议的 MCP 工具形态

```
creo_recolor_assembly(
  model_id, expected_revision,
  palette: { "<part_number|model_name>": [r,g,b], ... },   # RGB 0..1
  ambient=0.4, diffuse=0.7, highlite=0.5, shininess=0.4, transparency=0.0, reflection=0.0,
  dry_run: bool = false,      # 只列出组件→族的匹配结果与未匹配组件
  save: bool = true,          # 上色后 ProMdlSave（外观持久化进 .asm）
)
→ { painted, unmatched:[...], per_family_counts, readback:{...} }   # Set 后逐组件 Get 读回
```

要点：
1. 未匹配键 `dry_run=false` 时拒绝（与 AssetMate `recolor_assembly` 同语义），列出可用 part_number；
2. Set 后立即 Get 读回，回包带每族实际 RGB，读回不一致视为失败（本包 verify_color.cpp 的逻辑可直接搬）；
3. 结果属于显示属性：`save=true` 时持久化进装配文件；文档需写明"外观落在组件层，零件文件本身不改"的口径；
4. `ProWindowRepaint()` 必须在 Set 后调用（头文件注释明确要求），否则 UI 不刷新。

## 六、包内文件

| 文件 | 说明 |
|---|---|
| `recolor_worker.cpp` | 上色主程序源码（连接→遍历→上色→保存，含坑 1/坑 2 注释与 80 项族表） |
| `verify_color.cpp` | 读回校验程序源码（逐组件 Get，按 RGB 聚类输出 12 族计数） |
| `build_recolor.cmd` / `build_verify.cmd` | 编译脚本（与 MCP build.cmd 同款环境变量；注意：**须在 ASCII 路径下编译**，中文路径会让 cl 代码页 936 报 C1083） |
| `family_table.json` | 80 组件→族号真值表（由装配生成脚本导出，用于核对本包实测） |
| `RESULT.md` | 本次实测的两个 JSON 回执与 12 族核对表 |
| `README.md` | 本文件 |

## 七、复现步骤

```bat
:: 1) 编译（在 ASCII 路径，如 E:\wb_recolor_build\）
build_recolor.cmd      &:: → recolor_worker.exe
build_verify.cmd       &:: → verify_color.exe

:: 2) 运行（Creo 已打开目标装配；环境变量与 MCP bridge.py 一致）
set PRO_COMM_MSG_EXE=D:\Program Files\PTC\Creo 10.0.0.0\Common Files\x86e_win64\obj\pro_comm_msg.exe
set PATH=D:\Program Files\PTC\Creo 10.0.0.0\Common Files\x86e_win64\lib;D:\Program Files\PTC\Creo 10.0.0.0\Common Files\x86e_win64\obj;%PATH%
recolor_worker.exe STRANDBEEST_ASM 30
verify_color.exe  STRANDBEEST_ASM 30
```
