# 实测结果（2026-10-31，Creo 10.0.0.0，异步连接已运行会话）

## 上色回执（recolor_worker.exe STRANDBEEST_ASM 30）

```json
{"ok":true,"painted":80,"unpainted":0,"errors":0,"saved":true,"families":[1,4,2,18,6,6,6,6,6,12,12,1]}
```

families[] = 各零件族上色数，顺序 P01..P12。

## 读回校验（verify_color.exe STRANDBEEST_ASM 30）

```json
{"read":80,"families":[12,12,18,6,6,6,1,6,6,4,1,2]}
```

按组件访问序首个 RGB 聚类；12 族计数与期望逐项核对：

| 零件族 | 期望 | 读回 |
|---|---|---|
| P10 EBD 三角板 | 12 | 12 |
| P11 IGH 三角板 | 12 | 12 |
| P04 3Link 销 | 18 | 18 |
| P05 4Link 销 | 6 | 6 |
| P06 C 杆 | 6 | 6 |
| P07 F 杆 | 6 | 6 |
| P08 J 杆 | 6 | 6 |
| P09 K 杆 | 6 | 6 |
| P01 M Rotor | 1 | 1 |
| P02 Fixed Linkage AL | 4 | 4 |
| P03 AL Shaft | 2 | 2 |
| P12 Fan | 1 | 1 |

合计 80/80，全部 OK。

## 保存确认

ProMdlSave 产出 strandbeest_asm.asm.5 → .asm.8（版本号递增），外观随装配持久化。
