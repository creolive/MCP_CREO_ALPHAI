// recolor_worker.cpp — Pro/TOOLKIT asynchronous app: color all components
// of the Strandbeest assembly by part family, then save the assembly.
//
// Build: build_recolor.cmd (same INCLUDE/LIB environment as MCP build.cmd).
// Run:   creo_recolor_worker.exe <assembly_name> <connect_timeout_s>
// Env:   PRO_COMM_MSG_EXE + PATH pointing at Creo "Common Files"
//        x86e_win64 obj/lib (same as MCP bridge.py native_environment()).
//
// Console output: one JSON line {"ok":..,"painted":N,...}

#include <cstdio>
#include <cstring>
#include <cwchar>
#include <cstdlib>

extern "C" {
#include <ProToolkit.h>
#include <ProSizeConst.h>
#include <ProAsync.h>
#include <ProMdl.h>
#include <ProObjects.h>
#include <ProModelitem.h>
#include <ProAsmcomp.h>
#include <ProAsmcomppath.h>
#include <ProSolid.h>
#include <ProFeature.h>
#include <ProFeatType.h>
#include <ProSurface.h>
#include <ProWindows.h>
}

// ---------- palette: one color per part family (RGB 0..1) ----------
struct Family { const wchar_t *part_prefix; double rgb[3]; const wchar_t *label; };

static Family g_families[] = {
    { L"P01_M_ROTOR",          { 0.85, 0.32, 0.10 }, L"crank_orange"  },
    { L"P02_FIXED_LINKAGE_AL", { 0.30, 0.32, 0.90 }, L"frame_blue"    },
    { L"P03_AL_SHAFT",         { 0.10, 0.62, 0.30 }, L"shaft_green"   },
    { L"P04_3LINK_SHAFT",      { 0.95, 0.80, 0.10 }, L"pin3_yellow"   },
    { L"P05_4LINK_SHAFT",      { 0.55, 0.10, 0.75 }, L"pin4_purple"   },
    { L"P06_C_LINKAGE",        { 0.90, 0.15, 0.20 }, L"rod_c_red"     },
    { L"P07_F_LINKAGE",        { 0.95, 0.45, 0.10 }, L"rod_f_orange"  },
    { L"P08_J_LINKAGE",        { 0.15, 0.55, 0.85 }, L"rod_j_sky"     },
    { L"P09_K_LINKAGE",        { 0.85, 0.75, 0.20 }, L"rod_k_khaki"   },
    { L"P10_EBD",              { 0.20, 0.75, 0.45 }, L"tri_ebd_green" },
    { L"P11_IGH",              { 0.60, 0.25, 0.60 }, L"tri_igh_mauve" },
    { L"P12_FAN",              { 0.45, 0.47, 0.52 }, L"fan_grey"      },
};
static const int N_FAMILY = (int)(sizeof(g_families) / sizeof(g_families[0]));

typedef struct {
    int painted;
    int unpainted;
    int errors;
    int family_hits[N_FAMILY];
} Stats;
static Stats g_stats;
static ProSolid g_asm = nullptr;

// component insertion order -> family index (from MCP assembly job order c01..c80)
static const int g_comp_family[80] = {
    9,10,10,3,9,6,5,4,3,3,11,10,3,10,3,3,4,7,8,3,
    9,3,10,3,7,4,6,3,9,10,4,3,3,7,8,3,3,8,10,3,
    9,6,5,9,5,9,7,10,10,9,9,6,10,3,8,5,10,3,9,4,
    9,6,7,5,8,3,1,0,1,4,9,1,5,2,6,10,7,2,1,8
};
static int g_visit_index = 0;

static const Family *match_family_by_index(int idx) {
    if (idx < 0 || idx >= 80) return nullptr;
    return &g_families[g_comp_family[idx]];
}

static const Family *match_family(const ProMdlName name) {
    for (int i = 0; i < N_FAMILY; ++i) {
        size_t n = wcslen(g_families[i].part_prefix);
        if (wcsncmp(name, g_families[i].part_prefix, n) == 0)
            return &g_families[i];
    }
    return nullptr;
}

static ProError paint_one(ProSolid asm_solid, int feat_id, ProMdl mdl) {
    ProAsmcomppath path;
    ProIdTable tab;
    memset(tab, 0, sizeof(tab));
    tab[0] = feat_id;
    ProError e = ProAsmcomppathInit(asm_solid, tab, 1, &path);
    if (e != PRO_TK_NO_ERROR) { g_stats.errors++; return PRO_TK_NO_ERROR; }

    ProMdlName mdl_name;
    e = ProMdlNameGet(mdl, mdl_name);
    if (e != PRO_TK_NO_ERROR) { g_stats.errors++; return PRO_TK_NO_ERROR; }

    const Family *fam = match_family_by_index(g_visit_index);
    g_visit_index++;
    if (!fam) { g_stats.unpainted++; return PRO_TK_NO_ERROR; }

    ProAsmitem item;
    memset(&item, 0, sizeof(item));
    e = ProAsmcompAsmitemInit((ProMdl)asm_solid, feat_id, PRO_FEATURE,
                              (ProName)L"", &path, &item);
    if (e != PRO_TK_NO_ERROR) {
        g_stats.errors++;
        fwprintf(stderr, L"asmitem init fail %s feat %d: 0x%x\n", mdl_name, feat_id, e);
        return PRO_TK_NO_ERROR;
    }

    ProSurfaceAppearanceProps props;
    memset(&props, 0, sizeof(props));
    props.ambient      = 0.40;
    props.diffuse      = 0.70;
    props.highlite     = 0.50;
    props.shininess    = 0.40;
    props.transparency = 0.0;
    props.reflection   = 0.0;
    props.color_rgb[0] = fam->rgb[0];
    props.color_rgb[1] = fam->rgb[1];
    props.color_rgb[2] = fam->rgb[2];
    props.highlight_color[0] = fam->rgb[0];
    props.highlight_color[1] = fam->rgb[1];
    props.highlight_color[2] = fam->rgb[2];
    wcsncpy_s(props.name,        PRO_PATH_SIZE, fam->label, _TRUNCATE);
    wcsncpy_s(props.label,       PRO_PATH_SIZE, fam->label, _TRUNCATE);
    wcsncpy_s(props.description, PRO_PATH_SIZE, L"mechdog family color", _TRUNCATE);
    wcsncpy_s(props.keywords,    PRO_PATH_SIZE, L"mechdog", _TRUNCATE);

    e = ProMdlVisibleSideAppearancepropsSet(&item, 0, &props);
    if (e != PRO_TK_NO_ERROR) {
        g_stats.errors++;
        fwprintf(stderr, L"paint fail %s feat %d: 0x%x\n", mdl_name, feat_id, e);
        return PRO_TK_NO_ERROR;
    }
    for (int i = 0; i < N_FAMILY; ++i)
        if (fam == &g_families[i]) g_stats.family_hits[i]++;
    g_stats.painted++;
    return PRO_TK_NO_ERROR;
}

static ProError comp_visit(ProFeature *feat, ProError status, ProAppData data) {
    (void)status; (void)data;
    ProMdl mdl = nullptr;
    if (ProAsmcompMdlGet(feat, &mdl) != PRO_TK_NO_ERROR || !mdl) {
        g_stats.errors++;
        return PRO_TK_NO_ERROR;
    }
    return paint_one(g_asm, feat->id, mdl);
}

static ProError comp_filter(ProFeature *feat, ProError status, ProAppData data) {
    (void)status; (void)data;
    ProFeatType type;
    if (ProFeatureTypeGet(feat, &type) != PRO_TK_NO_ERROR)
        return PRO_TK_CONTINUE;
    return (type == PRO_FEAT_COMPONENT) ? PRO_TK_NO_ERROR : PRO_TK_CONTINUE;
}

int wmain(int argc, wchar_t *argv[]) {
    if (argc < 3) {
        fwprintf(stderr, L"usage: recolor_worker.exe <asm_name> <connect_timeout_s>\n");
        return 2;
    }
    ProName asm_name;
    wcsncpy_s(asm_name, PRO_NAME_SIZE, argv[1], _TRUNCATE);
    unsigned int timeout = (unsigned int)wcstoul(argv[2], nullptr, 10);
    if (timeout == 0) timeout = 30;

    ProProcessHandle process = {};
    char empty[] = "";
    ProBoolean random = PRO_B_FALSE;
    ProError e = ProEngineerConnect(empty, empty, empty, empty, PRO_B_FALSE,
                                    timeout, &random, &process);
    if (e != PRO_TK_NO_ERROR) {
        fwprintf(stderr, L"ProEngineerConnect failed: 0x%x\n", e);
        return 3;
    }

    ProMdl asm_mdl = nullptr;
    e = ProMdlInit(asm_name, PRO_ASSEMBLY, &asm_mdl);
    if (e != PRO_TK_NO_ERROR) {
        fwprintf(stderr, L"ProMdlInit(%s, PRO_ASSEMBLY) failed: 0x%x, trying current\n",
                 asm_name, e);
        e = ProMdlCurrentGet(&asm_mdl);
        if (e != PRO_TK_NO_ERROR) {
            fwprintf(stderr, L"ProMdlCurrentGet failed: 0x%x\n", e);
            ProEngineerDisconnect(&process, 10);
            return 4;
        }
    }
    g_asm = (ProSolid)asm_mdl;

    ProMdlDisplay(asm_mdl);

    e = ProSolidFeatVisit(g_asm, comp_visit, comp_filter, nullptr);
    if (e != PRO_TK_NO_ERROR && e != PRO_TK_E_NOT_FOUND)
        fwprintf(stderr, L"ProSolidFeatVisit: 0x%x\n", e);

    int window_id = -1;
    if (ProWindowCurrentGet(&window_id) == PRO_TK_NO_ERROR && window_id > 0)
        ProWindowRepaint(window_id);

    bool saved = false;
    e = ProMdlSave(asm_mdl);
    saved = (e == PRO_TK_NO_ERROR);
    if (!saved) fwprintf(stderr, L"ProMdlSave failed: 0x%x\n", e);

    printf("{\"ok\":%s,\"painted\":%d,\"unpainted\":%d,\"errors\":%d,\"saved\":%s,\"families\":[",
           (g_stats.errors == 0 && g_stats.painted > 0) ? "true" : "false",
           g_stats.painted, g_stats.unpainted, g_stats.errors, saved ? "true" : "false");
    for (int i = 0; i < N_FAMILY; ++i)
        printf("%s%d", i ? "," : "", g_stats.family_hits[i]);
    printf("]}\n");

    ProEngineerDisconnect(&process, 15);
    return (g_stats.errors == 0 && g_stats.painted > 0 && saved) ? 0 : 5;
}
