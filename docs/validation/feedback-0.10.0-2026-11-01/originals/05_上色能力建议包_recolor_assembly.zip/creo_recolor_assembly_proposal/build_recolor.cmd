@echo off
setlocal DisableDelayedExpansion
set "INCLUDE=C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\ucrt;C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\shared;C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\um;C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0\winrt;C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\include;C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\VS\include"
set "LIB=C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\ucrt\x64;C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0\um\x64;C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\lib\x64"
set "PATH=C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\HostX64\x64;%PATH%"

set "TK=D:\Program Files\PTC\Creo 10.0.0.0\Common Files\protoolkit"
set "SRC=E://<ASCII_BUILD_DIR>"   rem put the sources in an ASCII path, see README section 7

cl /nologo /MD /EHsc /std:c++17 /W3 /DPRO_MACHINE=36 /DPRO_OS=4 /DPRO_USE_VAR_ARGS /I"%TK%\includes" /c "%SRC%\recolor_worker.cpp" /Fo"%SRC%\recolor_worker.obj"
if errorlevel 1 exit /b 2

link /nologo /MACHINE:X64 /SUBSYSTEM:CONSOLE /OUT:"%SRC%\recolor_worker.exe" "%SRC%\recolor_worker.obj" "%TK%\x86e_win64\obj\protkmd_NU.lib" "%TK%\x86e_win64\obj\ptasyncmd.lib" "%TK%\x86e_win64\obj\ucore.lib" "%TK%\x86e_win64\obj\udata.lib" bcrypt.lib kernel32.lib user32.lib wsock32.lib advapi32.lib mpr.lib winspool.lib netapi32.lib psapi.lib gdi32.lib shell32.lib comdlg32.lib ole32.lib ws2_32.lib
if errorlevel 1 exit /b 3
exit /b 0
