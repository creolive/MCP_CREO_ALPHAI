
#include <cstdio>
#include <cstring>
#include <cwchar>
extern "C" {
#include <ProToolkit.h>
#include <ProSizeConst.h>
#include <ProCore.h>
#include <ProMdl.h>
#include <ProObjects.h>
#include <ProModelitem.h>
#include <ProAsmcomp.h>
#include <ProAsmcomppath.h>
#include <ProSolid.h>
#include <ProFeature.h>
#include <ProSurface.h>
}
static ProSolid g_asm = nullptr;
static int g_read = 0;
static int g_fam_counts[12];
static double g_last_rgb[12][3];
static int g_fam_of_comp[80];
static int g_idx = 0;

static ProError read_one(ProSolid asm_solid, int feat_id, ProMdl mdl) {
    ProAsmcomppath path; ProIdTable tab;
    memset(tab, 0, sizeof(tab)); tab[0] = feat_id;
    if (ProAsmcomppathInit(asm_solid, tab, 1, &path) != PRO_TK_NO_ERROR) return PRO_TK_NO_ERROR;
    ProMdlType mtype = PRO_MDL_PART; ProMdlTypeGet(mdl, &mtype);
    ProAsmitem item; memset(&item, 0, sizeof(item));
    if (ProAsmcompAsmitemInit((ProMdl)asm_solid, feat_id, (ProType)mtype, (ProName)L"", &path, &item) != PRO_TK_NO_ERROR)
        return PRO_TK_NO_ERROR;
    ProSurfaceAppearanceProps props; memset(&props, 0, sizeof(props));
    if (ProMdlVisibleSideAppearancepropsGet(&item, 0, &props) != PRO_TK_NO_ERROR) return PRO_TK_NO_ERROR;
    int fam = -1;
    for (int i = 0; i < 12; ++i) {
        if (!g_fam_counts[i] || (props.color_rgb[0]==g_last_rgb[i][0] && props.color_rgb[1]==g_last_rgb[i][1] && props.color_rgb[2]==g_last_rgb[i][2])) {
            if (!g_fam_counts[i]) { g_last_rgb[i][0]=props.color_rgb[0]; g_last_rgb[i][1]=props.color_rgb[1]; g_last_rgb[i][2]=props.color_rgb[2]; }
            fam = i; break;
        }
    }
    if (fam >= 0) { g_fam_counts[fam]++; g_fam_of_comp[g_idx] = fam; }
    g_read++; g_idx++;
    return PRO_TK_NO_ERROR;
}
static ProError v(ProFeature *f, ProError s, ProAppData d) {
    (void)s; (void)d;
    ProMdl m = nullptr;
    if (ProAsmcompMdlGet(f, &m) != PRO_TK_NO_ERROR || !m) return PRO_TK_NO_ERROR;
    return read_one(g_asm, f->id, m);
}
static ProError flt(ProFeature *f, ProAppData d) {
    (void)d; int t = 0;
    if (ProFeatureTypeGet(f, &t) != PRO_TK_NO_ERROR) return PRO_TK_CONTINUE;
    return (t == 1000) ? PRO_TK_NO_ERROR : PRO_TK_CONTINUE;
}
int wmain(int argc, wchar_t *argv[]) {
    if (argc < 3) return 2;
    ProName n; wcsncpy_s(n, PRO_NAME_SIZE, argv[1], _TRUNCATE);
    ProProcessHandle ph = {}; char e[] = ""; ProBoolean r = PRO_B_FALSE;
    if (ProEngineerConnect(e, e, e, e, PRO_B_FALSE, 30, &r, &ph) != PRO_TK_NO_ERROR) return 3;
    ProMdl m = nullptr;
    if (ProMdlInit(n, PRO_MDL_ASSEMBLY, &m) != PRO_TK_NO_ERROR) return 4;
    g_asm = (ProSolid)m;
    ProSolidFeatVisit(g_asm, v, flt, nullptr);
    printf("{\"read\":%d,\"families\":[", g_read);
    for (int i = 0; i < 12; ++i) printf("%s%d", i ? "," : "", g_fam_counts[i]);
    printf("]}\n");
    ProEngineerDisconnect(&ph, 10);
    return 0;
}
